package letsbuildthatapp.com.listviewlbta

import android.content.Context
import android.graphics.Color
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ListView
import android.widget.TextView
import kotlinx.android.synthetic.main.row_main.view.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val listView = findViewById<ListView>(R.id.main_listview)
//        val redColor = Color.parseColor("#FF0000")
//        listView.setBackgroundColor(redColor)

        listView.adapter = MyCustomAdapter() // this needs to be my custom adapter telling my list what to render
    }

    private class MyCustomAdapter: BaseAdapter() {

//        private val mContext: Context

        private val names = arrayListOf<String>(
                "6:28:10\\traspberrypi\\tOK\\n\" +\n" +
                        "                    \"6:28:10\\traspberrypi\\tOK\\n\" +\n" ,
                        "                    \"6:28:10\\twww.youtube.com\\tOK\\n\" +\n" ,
                        "                    \"6:28:10\\twww.youtube.com\\tOK\\n\" +\n" ,
                        "                    \"6:28:10\\tyoutube-ui.l.google.com\\tOK\\n\" +\n" ,
                        "                    \"6:28:10\\tspectrum.s3.amazonaws.com\\tOK\\n\" +\n" ,
                        "                    \"6:28:10\\tspectrum.s3.amazonaws.com\\tOK\\n\" +\n" ,
                        "                    \"6:28:05\\theartbeat.belkin.com\\tBlocked (blacklist)\\n\" +\n" ,
                        "                    \"6:28:05\\theartbeat.belkin.com\\tBlocked (blacklist)\\n\" +\n" ,
                        "                    \"6:28:05\\traspberrypi\\tOK\\n\" +\n" ,
                        "                    \"6:28:05\\traspberrypi\\tOK\\n\" +\n" ,
                        "                    \"6:28:01\\tcloudflare.com\\tOK\\n\" +\n" ,
                        "                    \"6:28:01\\tcloudflare.com\\tOK\\n\" +\n" ,
                        "                    \"6:27:56\\t173.1.168.192.in-addr.arpa\\tOK\\n\" +\n" ,
                        "                    \"6:27:53\\tcloudflare.com\\tOK\\n\" +\n" ,
                        "                    \"6:27:53\\tcloudflare.com\\tOK\\n\" +\n" ,
                        "                    \"6:27:52\\theartbeat.belkin.com\\tBlocked (blacklist)\\n\" +\n" ,
                        "                    \"6:27:52\\theartbeat.belkin.com\\tBlocked (blacklist)\\n\" +\n" ,
                        "                    \"6:27:49\\tcloudflare.com\\tOK\\n\" +\n" ,
                        "                    \"6:27:49\\tcloudflare.com\\tOK\\n\" +\n" ,
                        "                    \"6:27:48\\tgeomobileservices-pa.googleapis.com\\tOK\\n\" +\n" ,
                        "                    \"6:27:48\\tgeomobileservices-pa.googleapis.com\\tOK\\n\" +\n" ,
                        "                    \"6:27:46\\tspectrum.s3.amazonaws.com\\tOK\\n\" +\n" ,
                        "                    \"6:27:46\\tspectrum.s3.amazonaws.com\\tOK\\n\" +\n" ,
                        "                    \"6:27:46\\tcloudflare.com\\tOK\\n\" +\n" ,
                        "                    \"6:27:46\\tcloudflare.com\\tOK\\n\" +\n" ,
                        "                    \"6:27:38\\theartbeat.belkin.com\\tBlocked (blacklist)\\n\" +\n" ,
                        "                    \"6:27:38\\theartbeat.belkin.com\\tBlocked (blacklist)\\n\" +\n" ,
                        "                    \"6:27:35\\twww.googleapis.com\\tOK\\n\" +\n" ,
                        "                    \"6:27:35\\twww.googleapis.com\\tOK\\n\" +\n" ,
                        "                    \"6:27:34\\tconnectivitycheck.gstatic.com\\tOK\\n\" +\n" ,
                        "                    \"6:27:32\\tandroid.clients.google.com\\tOK\\n\" +\n" ,
                        "                    \"6:27:26\\tspectrum.s3.amazonaws.com\\tOK\\n\" +\n" ,
                        "                    \"6:27:26\\tspectrum.s3.amazonaws.com\\tOK\\n\" +\n" ,
                        "                    \"6:27:25\\theartbeat.belkin.com\\tBlocked (blacklist)\\n\" +\n" ,
                        "                    \"6:27:25\\theartbeat.belkin.com\\tBlocked (blacklist)\\n\" +\n" ,
                        "                    \"6:27:12\\theartbeat.belkin.com\\tBlocked (blacklist)\\n\" +\n" ,
                        "                    \"6:27:12\\theartbeat.belkin.com\\tBlocked (blacklist)\\n\" +\n" ,
                        "                    \"6:27:07\\tfs.microsoft.com\\tBlocked (gravity)\\n\" +\n" ,
                        "                    \"6:27:06\\tapi.amazon.com\\tOK\\n\" +\n" ,
                        "                    \"6:26:59\\theartbeat.belkin.com\\tBlocked (blacklist)\\n\" +\n" ,
                        "                    \"6:26:59\\theartbeat.belkin.com\\tBlocked (blacklist)\\n\" +\n" ,
                        "                    \"6:26:57\\tcloudflare.com\\tOK\\n\" +\n" ,
                        "                    \"6:26:57\\tcloudflare.com\\tOK\\n\" +\n" ,
                        "                    \"6:26:49\\twww.googleapis.com\\tOK\\n\" +\n" ,
                        "                    \"6:26:49\\twww.googleapis.com\\tOK\\n\" +\n" ,
                        "                    \"6:26:49\\tcloudflare.com\\tOK\\n\" +\n" ,
                        "                    \"6:26:49\\tcloudflare.com\\tOK\\n\" +\n" ,
                        "                    \"6:26:48\\tandroid.clients.google.com\\tOK\\n\" +\n" ,
                        "                    \"6:26:48\\tandroid.clients.google.com\\tOK\\n\" +\n" ,
                        "                    \"6:26:46\\theartbeat.belkin.com\\tBlocked (blacklist)\\n\" +\n" ,
                        "                    \"6:26:46\\theartbeat.belkin.com\\tBlocked (blacklist)\\n\" +\n" ,
                        "                    \"6:26:45\\tcloudflare.com\\tOK\\n\" +\n" ,
                        "                    \"6:26:45\\tcloudflare.com\\tOK\\n\" +\n" ,
                        "                    \"6:26:43\\tcloudflare.com\\tOK\\n\" +\n" ,
                        "                    \"6:26:43\\tcloudflare.com\\tOK\\n\" +\n" ,
                        "                    \"6:26:38\\tgetpocket.cdn.mozilla.net\\tOK\\n\" +\n" ,
                        "                    \"6:26:38\\tgetpocket.cdn.mozilla.net\\tOK\\n\" +\n" ,
                        "                    \"6:26:38\\te8220.dscd.akamaiedge.net\\tOK\\n\" +\n" ,
                        "                    \"6:26:38\\timg-getpocket.cdn.mozilla.net\\tOK\\n\" +\n" ,
                        "                    \"6:26:38\\timg-getpocket.cdn.mozilla.net\\tOK\\n\" +\n" ,
                        "                    \"6:26:34\\tcloudflare.com\\tOK\\n\" +\n" ,
                        "                    \"6:26:34\\tcloudflare.com\\tOK\\n\" +\n" ,
                        "                    \"6:26:33\\theartbeat.belkin.com\\tBlocked (blacklist)\\n\" +\n" ,
                        "                    \"6:26:33\\theartbeat.belkin.com\\tBlocked (blacklist)\\n\" +\n" ,
                        "                    \"6:26:28\\tmsh.amazon.com\\tBlocked (gravity)\\n\" +\n" ,
                        "                    \"6:26:28\\tapi.amazonalexa.com\\tOK\\n\" +\n" ,
                        "                    \"6:26:26\\tspectrum.s3.amazonaws.com\\tOK\\n\" +\n" ,
                        "                    \"6:26:26\\taviary.amazon.com\\tOK\\n\" +\n" ,
                        "                    \"6:26:26\\tftv-smp.ntp-fireos.com\\tOK\\n\" +\n" ,
                        "                    \"6:26:24\\ts.amazon-adsystem.com\\tBlocked (gravity)\\n\" +\n" ,
                        "                    \"6:26:24\\tcloudflare.com\\tOK\\n\" +\n" ,
                        "                    \"6:26:24\\tcloudflare.com\\tOK\\n\" +\n" ,
                        "                    \"6:26:20\\theartbeat.belkin.com\\tBlocked (blacklist)\\n\" +\n" ,
                        "                    \"6:26:20\\theartbeat.belkin.com\\tBlocked (blacklist)\\n\" +\n" ,
                        "                    \"6:26:13\\tcloudflare.com\\tOK\\n\" +\n" ,
                        "                    \"6:26:13\\tcloudflare.com\\tOK\\n\" +\n" ,
                        "                    \"6:26:09\\ts.amazon-adsystem.com\\tBlocked (gravity)\\n\" +\n" ,
                        "                    \"6:26:09\\tcloudflare.com\\tOK\\n\" +\n" ,
                        "                    \"6:26:09\\tclients3.google.com\\tOK\\n\" +\n" ,
                        "                    \"6:26:09\\tcloudflare.com\\tOK\\n\" +\n" ,
                        "                    \"6:26:09\\tclients3.google.com\\tOK\\n\" +\n" ,
                        "                    \"6:26:07\\twww.netgear.com\\tBlocked (blacklist)\\n\" +\n" ,
                        "                    \"6:26:07\\theartbeat.belkin.com\\tBlocked (blacklist)\\n\" +\n" ,
                        "                    \"6:26:07\\theartbeat.belkin.com\\tBlocked (blacklist)\\n\" +\n" ,
                        "                    \"6:26:07\\tsetup.icloud.com\\tOK\\n\" +\n" ,
                        "                    \"6:26:05\\tspectrum.s3.amazonaws.com\\tOK\\n\" +\n" ,
                        "                    \"6:26:05\\tspectrum.s3.amazonaws.com\\tOK\\n\" +\n" ,
                        "                    \"6:26:03\\tgsp64-ssl.ls.apple.com\\tOK\\n\" +\n" ,
                        "                    \"6:26:02\\ts.amazon-adsystem.com\\tBlocked (gravity)\\n\" +\n" ,
                        "                    \"6:25:58\\tcloudflare.com\\tOK\\n\" +\n" ,
                        "                    \"6:25:57\\thistory.google.com\\tOK\\n\" +\n" ,
                        "                    \"6:25:55\\tmsh.amazon.com\\tBlocked (gravity)\\n\" +\n" ,
                        "                    \"6:25:55\\ts.amazon-adsystem.com\\tBlocked (gravity)\\n\" +\n" ,
                        "                    \"6:25:54\\theartbeat.belkin.com\\tBlocked (blacklist)\\n\" +\n" ,
                        "                    \"6:25:54\\theartbeat.belkin.com\\tBlocked (blacklist)\\n\" +\n" ,
                        "                    \"6:25:53\\twww.google.com\\tOK\\n\" +\n" ,
                        "                    \"6:25:52\\tconnectivitycheck.gstatic.com\\tOK\\n\" +\n" ,
                        "                    \"6:25:51\\tpandoramedia.sc.omtrdc.net\\tBlocked (gravity)\\n\" +\n" ,
                        "                    \"6:25:50\\tpandoramedia-mkt-prod1-t.campaign.adobe.com\\tBlocked (gravity)\\n\""
        )

//        init {
//            mContext = context
//        }

        // responsible for how many rows in my list
        override fun getCount(): Int {
            return names.size
        }

        // you can also ignore this
        override fun getItemId(position: Int): Long {
            return position.toLong()
        }

        // you can ignore this for now
        override fun getItem(position: Int): Any {
            return "TEST STRING"
        }

        // responsible for rendering out each row
        override fun getView(position: Int, convertView: View?, viewGroup: ViewGroup?): View {

            val rowMain: View

            // checking if convertView is null, meaning we have to inflate a new row
            if (convertView == null) {
                val layoutInflater = LayoutInflater.from(viewGroup!!.context)
                rowMain = layoutInflater.inflate(R.layout.row_main, viewGroup, false)

//                Log.v("getView", "calling findViewById which is expensive")
//                val nTextView = rowMain.name_textView
//                val pTextView = rowMain.position_textview
//                val nameTextView = rowMain.findViewById<TextView>(R.id.name_textView)
//                val positionTextView = rowMain.findViewById<TextView>(R.id.position_textview)
                val viewHolder = ViewHolder(rowMain.name_textView, rowMain.position_textview)
                rowMain.tag = viewHolder

            } else {
                // well, we have our row as convertView, so just set rowMain as that view
                rowMain = convertView
            }


            val viewHolder = rowMain.tag as ViewHolder
            viewHolder.nameTextView.text = names.get(position)
            viewHolder.positionTextView.text = "Row number: $position"
            return rowMain
        }

        private class ViewHolder(val nameTextView: TextView, val positionTextView: TextView)

    }

}
